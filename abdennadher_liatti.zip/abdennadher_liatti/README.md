# Reed Muller
## Raed Abdennadher et Steven Liatti

Pour lancer le programme, se déplacer dans src/ puis :
javac Main.java
java Main

Dans le dossier d'images se trouvent les images fournies + les images calculées avec le programme pour 
différents cas de figure.

En l'état tout fonctionne !

